// csv-test
// takes data from a .txt file and reads it into an array of structs, which helps in organizing the data.
// Create array of structs to store the informaion

import Foundation
struct Test {
    var date:String
    var name:String
    var result:String
}

// The array, which constains Test structs.
var tests = [Test]()

// CSV to Array Conversion Function
// Takes one argument and returns nothing
// Converts the contents of a given file (givenFile) into an array of structs defined earlier in the code.
func CSVtoArray(givenFile: String) {
    // Find the path to the given file, which is unwrapped and put into a string format.
    let dataPath:String = String(Bundle.main.path(forResource: givenFile, ofType: "csv")!)
    // print(dataPath)
    var data = ""
    do {
        // Convert the entire contents of the file into one string, "data". The string is the path to the file.
        // data = try String(contentsOfFile: "/Users/toth/Desktop/csv-test.playground/Resources/test-file.csv")
        data = try String(contentsOfFile: dataPath)
        //print(data)
    } catch {
        print("Error")
    }
    // Split into lines
    var rows = data.components(separatedBy: "\n")

    // Remove first row (header row) if necessary. Can be commented out if necessary
    rows.removeFirst()

    // Split into columns
    for row in rows {
        let columns = row.components(separatedBy: ",")
        
        // Convert into correct data type
        let testDate = columns[0]
        // This exits the loop if it's arrived at the end of the file.
        if (testDate == "") {
            break
        }
        let testName = columns[1]
        let testResult = columns[2]

        // Sets "test" as a struct with the given date, name, and result
        let test = Test(date: testDate, name: testName, result: testResult)
        // print(test.date)
        tests.append(test)
    }
}

// Set the name of the file to be converted
var fileName = "test-file"

// Call the CSV to Array Function
CSVtoArray(givenFile: fileName)

// Data can now be accessed via dot notation
print(tests[2].date)
print(tests[0].name)
print(tests[1].result)
