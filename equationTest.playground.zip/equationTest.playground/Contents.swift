
// Initialize Variables; lowRGB and highRGB are constants, while sampRGB is the given sample
let lowRGB:[Int] = [232, 233, 237] // Indicates low concentration, closer to white
let highRGB:[Int] = [39, 45, 227] // Indicates high concentration, deeper / darker in color
let sampRGB:[Int] = [40, 50, 230] // RGB values of the sample region

// Still initializing; lowConc and highConc are also constants
let lowConc:Float = 0 // Low concentration; units don't matter as long as they're the same between all 3
let highConc:Float = 100 // High concentration
var sampConc:Float = 0 // Concentration of sample, given a value of 0 to initialize

// Find Slope FCN
// Given two lists of RGB values (one high concentration (RGB2) and one low concentration(RGB1)) as well as the specific concentrations of those values
// (given as Conc1 and Conc2), returns a linear rate of change corresponding to the change in RGB value and the change in concentration.
func findSlope(RGB1: [Int], RGB2: [Int], Conc1: Float, Conc2: Float, num: Int) -> Float {
    let newSlope = Float(RGB1[num] - RGB2[num]) / (Conc1 - Conc2)
    return newSlope
}

// Calculate Concentration FCN
// Given a list of low concentration RGB values (RGB1), the list of RGB values from the sample (newRGB), and the slope (preferrably the slope found in
// the findSlope function), returns an approximate concentration based on the one RGB value given. Shouldn't be taken as a complete result,
// and should be considered (maybe averaged?) in tandem with the other RGB values to give a total approximation.
func calcConc(RGB1: [Int], newRGB: [Int], slope: Float, num: Int) -> Float {
    let newConc:Float = Float(newRGB[num] - RGB1[num]) / slope
    return newConc
}

// This is just using the code to find the concentration. The concentration (assuming the flare is red, green, or blue) can be found by looking
// at the result of calcConc for the other two values.
// I still need to work on finding it if the flare happens to be yellow, orange, purple, etc.

// Find the slopes of the lines between the RGB values of the low and high concentration
var redSlope:Float = findSlope(RGB1: lowRGB, RGB2: highRGB, Conc1: lowConc, Conc2: highConc, num: 0)
print("Red Slope: ", redSlope)

var greenSlope:Float = findSlope(RGB1: lowRGB, RGB2: highRGB, Conc1: lowConc, Conc2: highConc, num: 1)
print("Green Slope: ", greenSlope)

var blueSlope:Float = findSlope(RGB1: lowRGB, RGB2: highRGB, Conc1: lowConc, Conc2: highConc, num: 2)
print("Blue Slope: ", blueSlope)

print("=========")

// Calculate concentration from the slope
var redConc = calcConc(RGB1: lowRGB, newRGB: sampRGB, slope: redSlope, num: 0)
print("Red Concentration: ", redConc)

var greenConc = calcConc(RGB1: lowRGB, newRGB: sampRGB, slope: redSlope, num: 1)
print("Green Concentration: ", greenConc)

var blueConc = calcConc(RGB1: lowRGB, newRGB: sampRGB, slope: redSlope, num: 2)
print("Blue Concentration: ", blueConc)

print("=========")

// Print out the approximate sample concentration
sampConc = (redConc + greenConc) / 2
print("The concentration of the sample is about", sampConc, " units.")
